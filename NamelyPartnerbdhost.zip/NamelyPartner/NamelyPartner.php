<?php
/**
 * WHMCS Registrar Module for Namely Partner
 *
 * @copyright Copyright (c) Namely Partner
 * @license https://www.whmcs.com/license/ WHMCS Eula
 * @note Namely Partner is a domain registrar partner, not a registry
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Domains\DomainLookup\ResultsList;
use WHMCS\Domains\DomainLookup\SearchResult;
use WHMCS\Results\ResultsList as TldResultsList;
use WHMCS\Domain\TopLevel\ImportItem;
use WHMCS\Carbon;
use WHMCS\Domain\Registrar\Domain;

/**
 * Define module related meta data.
 */
function namelypartner_MetaData()
{
    return array(
        'DisplayName' => 'Namely Partner',
        'APIVersion' => '1.1',
        'Description' => 'Complete WHMCS integration for Namely Partner domain management with full automation support.',
        'RequiresServer' => false,
        'DefaultNonSSLPort' => '80',
        'DefaultSSLPort' => '443',
        'ServiceSingleSignOnLabel' => 'Login to Namely Partner',
        'AdminSingleSignOnLabel' => 'Login to Namely Partner as Admin',
        'ListAccountsUniqueIdentifierDisplayName' => 'Domain',
        'ListAccountsUniqueIdentifierField' => 'domain',
        'ListAccountsProductField' => 'domain',
        'SupportsExtraFields' => true,
        'SupportsDNSManagement' => true, // Enable DNS management support
    );
}

/**
 * Define registrar configuration options.
 */
function namelypartner_getConfigArray()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Namely Partner',
        ),
        'Description' => array(
            'Type' => 'System',
            'Value' => 'Namely Partner API Integration for domain registration and management',
        ),
        'ApiKey' => array(
            'Type' => 'text',
            'Size' => '50',
            'Default' => '',
            'Description' => 'Enter your Namely Partner API Key. Connection will be validated on first API call.',
        ),
        'TestMode' => array(
            'Type' => 'yesno',
            'Description' => 'Enable test mode (use test environment)',
        ),
        'DocumentListUrl' => array(
            'Type' => 'text',
            'Size' => '100',
            'Default' => '',
            'Description' => 'URL for Required Documents list (will be shown as a link in domain registration form)',
        ),
    );
}


/**
 * Check if WHMCS error logging is enabled
 * 
 * @return bool True if error logging is enabled
 */
function namelypartner_IsErrorLoggingEnabled()
{
    // Check if logModuleCall function exists
    if (!function_exists('logModuleCall')) {
        return false;
    }
    
    // Check WHMCS LogErrors setting
    if (function_exists('get_query_val')) {
        $logErrors = get_query_val('tblconfiguration', 'value', array('setting' => 'LogErrors'));
        if ($logErrors == 'on' || $logErrors == '1') {
            return true;
        }
    }
    
    return false;
}

/**
 * Make API request to Namely Partner
 */
function namelypartner_ApiRequest($params, $endpoint, $method = 'GET', $data = array())
{
    $apiKey = isset($params['ApiKey']) ? $params['ApiKey'] : '';
    
    // API URLs
    $productionUrl = 'https://api.namely.com.bd/v1';
    $testUrl = 'http://namely-semi-final.test/api/v1';
    
    // WHMCS checkboxes return "on" when checked, empty string when unchecked
    $testMode = (isset($params['TestMode']) && $params['TestMode'] == 'on');
    
    // Use WHMCS global debug mode setting
    // Check if WHMCS debug mode is enabled via global configuration
    $debugMode = false;
    if (defined('_WHMCS_DEBUG') && _WHMCS_DEBUG) {
        $debugMode = true;
    } elseif (function_exists('get_query_val')) {
        // Try to get debug mode from database
        $debugSetting = get_query_val('tblconfiguration', 'value', array('setting' => 'DebugMode'));
        $debugMode = ($debugSetting == 'on' || $debugSetting == '1');
    }
    
    // Validate API configuration
    if (empty($apiKey)) {
        return array(
            'success' => false,
            'error' => 'API Key is not configured. Please enter your API key in module settings.',
        );
    }
    
    // Select API URL based on test mode
    $apiUrl = $testMode ? $testUrl : $productionUrl;
    
    // Construct full URL
    $url = rtrim($apiUrl, '/') . '/' . ltrim($endpoint, '/');
    
    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, !$testMode);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, !$testMode ? 2 : 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    
    // Set headers
    $headers = array(
        'X-Partner-Api-Key: ' . trim($apiKey),
        'Content-Type: application/json',
        'Accept: application/json',
    );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    // Set method and data
    if ($method == 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    } elseif ($method == 'PUT') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        if (!empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    } elseif ($method == 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    }
    
    // Execute request
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    // Log API call if error logging is enabled
    if (namelypartner_IsErrorLoggingEnabled()) {
        $logData = array(
            'url' => $url,
            'method' => $method,
            'headers' => array(
                'X-Partner-Api-Key' => substr($apiKey, 0, 8) . '...',
                'Content-Type' => 'application/json',
            ),
            'request_data' => $data,
        );
        
        $logResponse = array(
            'http_code' => $httpCode,
            'response' => $response,
            'curl_error' => $error,
        );
        
        logModuleCall(
            'namelypartner',
            $method . ' ' . $endpoint,
            $logData,
            $logResponse,
            $response,
            array($apiKey)
        );
    }
    
    if ($error) {
        return array(
            'success' => false,
            'error' => 'cURL Error: ' . $error,
        );
    }
    
    $result = json_decode($response, true);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        return array(
            'success' => true,
            'data' => $result,
        );
    } else {
        // Extract error message - prioritize message field, then error field
        $errorMessage = 'API Error: HTTP ' . $httpCode;
        
        if (isset($result['message']) && !empty($result['message'])) {
            $errorMessage = $result['message'];
        } elseif (isset($result['error'])) {
            // Handle case where error might be boolean true/false or a string
            if (is_string($result['error']) && !empty($result['error'])) {
            $errorMessage = $result['error'];
            } elseif (is_bool($result['error']) && $result['error'] === true && isset($result['message'])) {
                // If error is boolean true, use message field
                $errorMessage = $result['message'];
            }
        }
        
        return array(
            'success' => false,
            'error' => $errorMessage,
            'http_code' => $httpCode,
            'data' => $result,
        );
    }
}



/**
 * Get TLD pricing for import
 * 
 * This function allows WHMCS to fetch current TLD pricing from the registrar.
 * Returns a ResultsList containing ImportItem objects.
 * 
 * @param array $params common module parameters
 * @return \WHMCS\Results\ResultsList|array ResultsList on success, array with error key on failure
 * @see https://developers.whmcs.com/domain-registrars/tld-pricing-sync/
 */
function namelypartner_GetTldPricing(array $params)
{
    try {
        // Fetch all available TLDs with pricing from API
        $result = namelypartner_ApiRequest(
            $params,
            '/partner-api/pricing/tlds',
            'GET'
        );
        
        if (!$result['success']) {
            return array(
                'error' => $result['error'],
            );
        }
        
        // API returns data wrapped in 'data' key
        $responseData = $result['data'];
        $tlds = isset($responseData['data']) ? $responseData['data'] : $responseData;
    
    // Check if we have valid data
    if (empty($tlds) || !is_array($tlds)) {
        return array('error' => 'No TLD data received from API');
    }
    
    // Use WHMCS ResultsList as per documentation
    $results = new TldResultsList();
    $currency = 'BDT'; // Default currency
    
    // Format pricing data for WHMCS using ImportItem objects
    foreach ($tlds as $index => $tldData) {
        // Validate TLD data structure
        if (!is_array($tldData)) {
            continue;
        }
        
        // Get TLD extension - try multiple possible field names
        $tld = '';
        if (isset($tldData['extension'])) {
            $tld = $tldData['extension'];
        } elseif (isset($tldData['tld'])) {
            $tld = $tldData['tld'];
        } elseif (isset($tldData['name'])) {
            $tld = $tldData['name'];
        }
        
        // Skip if no valid TLD
        if (empty($tld)) {
            continue;
        }
        
        // Ensure TLD starts with a dot
        if (substr($tld, 0, 1) !== '.') {
            $tld = '.' . $tld;
        }
        
        // Get base prices - handle multiple possible API response formats
        $registerPrice = 0;
        $renewPrice = 0;
        $transferPrice = 0;
        
        // Try nested structure first (purchase_price.base)
        if (isset($tldData['purchase_price']['base'])) {
            $registerPrice = (float)$tldData['purchase_price']['base'];
        } elseif (isset($tldData['purchase_price'])) {
            $registerPrice = (float)$tldData['purchase_price'];
        } elseif (isset($tldData['registration_price'])) {
            $registerPrice = (float)$tldData['registration_price'];
        }
        
        // Renewal price
        if (isset($tldData['renewal_price']['base'])) {
            $renewPrice = (float)$tldData['renewal_price']['base'];
        } elseif (isset($tldData['renewal_price'])) {
            $renewPrice = (float)$tldData['renewal_price'];
        } else {
            $renewPrice = $registerPrice; // Fallback to register price
        }
        
        // Transfer price
        if (isset($tldData['transfer_price']['base'])) {
            $transferPrice = (float)$tldData['transfer_price']['base'];
        } elseif (isset($tldData['transfer_price'])) {
            $transferPrice = (float)$tldData['transfer_price'];
        } else {
            $transferPrice = $registerPrice; // Fallback to register price
        }
        
        // Skip TLDs with zero prices
        if ($registerPrice <= 0) {
            continue;
        }
        
        // Override with customer base prices if available
        if (isset($tldData['customer_price']) && is_array($tldData['customer_price'])) {
            $customerPrice = $tldData['customer_price'];
            
            // Try nested base price first
            if (isset($customerPrice['base'])) {
                $registerPrice = (float)$customerPrice['base'];
            } elseif (isset($customerPrice['purchase_price'])) {
                $registerPrice = (float)$customerPrice['purchase_price'];
            }
            
            // Use first year renewal price if available
            if (isset($customerPrice['yearly_pricing']['renewal']['1'])) {
                $renewPrice = (float)$customerPrice['yearly_pricing']['renewal']['1'];
            } elseif (isset($customerPrice['renewal_price'])) {
                $renewPrice = (float)$customerPrice['renewal_price'];
            }
            
            // Use first year transfer price if available
            if (isset($customerPrice['yearly_pricing']['transfer']['1'])) {
                $transferPrice = (float)$customerPrice['yearly_pricing']['transfer']['1'];
            } elseif (isset($customerPrice['transfer_price'])) {
                $transferPrice = (float)$customerPrice['transfer_price'];
            }
            
        }
        
        // Get min/max years - try both naming conventions
        $minYears = 1;
        $maxYears = 10;
        
        if (isset($tldData['min_period'])) {
            $minYears = intval($tldData['min_period']);
        } elseif (isset($tldData['minYears'])) {
            $minYears = intval($tldData['minYears']);
        }
        
        if (isset($tldData['max_period'])) {
            $maxYears = intval($tldData['max_period']);
        } elseif (isset($tldData['maxYears'])) {
            $maxYears = intval($tldData['maxYears']);
        }
        
        // Get EPP requirement
        $eppRequired = isset($tldData['epp_required']) ? (bool)$tldData['epp_required'] : false;
        
        // Get currency from TLD data or use default
        $tldCurrency = isset($tldData['currency']) ? $tldData['currency'] : $currency;
        
        // Create ImportItem object as per WHMCS documentation
        try {
            $item = (new ImportItem())
                ->setExtension($tld)
                ->setMinYears($minYears)
                ->setMaxYears($maxYears)
                ->setRegisterPrice($registerPrice)
                ->setRenewPrice($renewPrice)
                ->setTransferPrice($transferPrice)
                ->setCurrency($tldCurrency)
                ->setEppRequired($eppRequired);
            
            // Add to results list
            $results[] = $item;
            
        } catch (Exception $e) {
            // Skip TLD if ImportItem creation fails
            continue;
            }
        }
        
        // Return the ResultsList object as per WHMCS documentation
        return $results;
        
    } catch (Exception $e) {
        return array();
    }
}

/**
 * Register a domain
 */
function namelypartner_RegisterDomain($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    // Prepare nameservers
    $nameservers = array();
    for ($i = 1; $i <= 5; $i++) {
        if (!empty($params["ns{$i}"])) {
            $nameservers[] = $params["ns{$i}"];
        }
    }
    
    // Note: Default nameservers removed from config
    // If no nameservers provided, domain will use registrar defaults
    
    // Helper function to clean phone number (remove dots)
    $cleanPhone = function($phone) {
        if (empty($phone)) {
            return '';
        }
        return str_replace('.', '', $phone);
    };
    
    // Prepare contact information
    // Use contactdetails if available (WHMCS 7.0+), otherwise use main params
    $getContactData = function($contactType = 'Registrant') use ($params, $cleanPhone) {
        if (isset($params['contactdetails'][$contactType])) {
            $contact = $params['contactdetails'][$contactType];
            $phone = $contact['Phone Number'] ?? '';
            return array(
                'name' => trim(($contact['First Name'] ?? '') . ' ' . ($contact['Last Name'] ?? '')),
                'email' => $contact['Email Address'] ?? '',
                'phone' => $cleanPhone($phone),
                'organization' => $contact['Company Name'] ?? '',
                'address1' => $contact['Address 1'] ?? '', // API expects address1
                'address' => $contact['Address 1'] ?? '', // Keep for backward compatibility
                'city' => $contact['City'] ?? '',
                'state' => $contact['State'] ?? '',
                'postcode' => $contact['Postcode'] ?? '',
                'country' => $contact['Country'] ?? '',
            );
        } else {
            // Fallback to main params (for registrant)
            $phone = !empty($params['phonenumberformatted']) ? $params['phonenumberformatted'] : ($params['phonenumber'] ?? '');
            return array(
                'name' => trim(($params['firstname'] ?? '') . ' ' . ($params['lastname'] ?? '')),
                'email' => $params['email'] ?? '',
                'phone' => $cleanPhone($phone),
                'organization' => $params['companyname'] ?? '',
                'address1' => $params['address1'] ?? '', // API expects address1
                'address' => $params['address1'] ?? '', // Keep for backward compatibility
                'city' => $params['city'] ?? '',
                'state' => $params['state'] ?? '',
                'postcode' => $params['postcode'] ?? '',
                'country' => $params['country'] ?? '',
    );
        }
    };
    
    // Get registrant contact (required)
    $registrantContact = $getContactData('Registrant');
    
    // Validate required registrant fields
    if (empty($registrantContact['name']) || empty($registrantContact['email']) || 
        empty($registrantContact['phone']) || empty($registrantContact['address1']) ||
        empty($registrantContact['city']) || empty($registrantContact['country'])) {
        return array(
            'error' => 'Registrant contact information is incomplete. Please ensure all required fields are filled.',
        );
    }
    
    // Get other contacts (use registrant as fallback)
    $adminContact = $getContactData('Admin');
    if (empty($adminContact['name'])) $adminContact = $registrantContact;
    
    $technicalContact = $getContactData('Technical');
    if (empty($technicalContact['name'])) $technicalContact = $registrantContact;
    
    $billingContact = $getContactData('Billing');
    if (empty($billingContact['name'])) $billingContact = $registrantContact;
    
    // Get additional fields
    $additionalFields = array();
    if (isset($params['additionalfields']) && is_array($params['additionalfields'])) {
    foreach ($params['additionalfields'] as $key => $value) {
        $additionalFields[$key] = $value;
        }
    }
    
    // Extract NID from additional fields (check multiple possible field names)
    $nidNumber = '';
    if (isset($additionalFields['NID Number']) && !empty($additionalFields['NID Number'])) {
        $nidNumber = trim($additionalFields['NID Number']);
    } elseif (isset($additionalFields['NID/Passport Number']) && !empty($additionalFields['NID/Passport Number'])) {
        $nidNumber = trim($additionalFields['NID/Passport Number']);
    } elseif (isset($additionalFields['nid_number']) && !empty($additionalFields['nid_number'])) {
        $nidNumber = trim($additionalFields['nid_number']);
    } elseif (isset($additionalFields['ID Number']) && !empty($additionalFields['ID Number'])) {
        $nidNumber = trim($additionalFields['ID Number']);
    } elseif (isset($additionalFields['Authorized Person NID']) && !empty($additionalFields['Authorized Person NID'])) {
        $nidNumber = trim($additionalFields['Authorized Person NID']);
    }
    
    // Add NID to registrant contact (required by API)
    if (!empty($nidNumber)) {
        $registrantContact['nid'] = $nidNumber;
    }
    
    // Validate NID is present
    if (empty($registrantContact['nid'])) {
        return array(
            'error' => 'NID Number is required for domain registration. Please fill in the NID Number field.',
        );
    }
    
    // Extract Organization Name from additional fields for registrant_contact
    // Check multiple possible field names based on TLD
    $organizationName = '';
    if (isset($additionalFields['Organization Name']) && !empty($additionalFields['Organization Name'])) {
        $organizationName = trim($additionalFields['Organization Name']);
    } elseif (isset($additionalFields['Company Name']) && !empty($additionalFields['Company Name'])) {
        $organizationName = trim($additionalFields['Company Name']);
    } elseif (isset($additionalFields['Institution Name']) && !empty($additionalFields['Institution Name'])) {
        $organizationName = trim($additionalFields['Institution Name']);
    } elseif (isset($additionalFields['University/College Name']) && !empty($additionalFields['University/College Name'])) {
        $organizationName = trim($additionalFields['University/College Name']);
    } elseif (isset($additionalFields['Department/Agency']) && !empty($additionalFields['Department/Agency'])) {
        $organizationName = trim($additionalFields['Department/Agency']);
    }
    
    // Set organization name in registrant contact
    if (!empty($organizationName)) {
        $registrantContact['organization'] = $organizationName;
    }
    
    // Get client company name from WHMCS profile for customer field
    $clientCompanyName = '';
    if (isset($params['clientdetails']['companyname']) && !empty($params['clientdetails']['companyname'])) {
        $clientCompanyName = trim($params['clientdetails']['companyname']);
    } elseif (isset($params['userid']) && !empty($params['userid'])) {
        // Query database for client company name
        $clientCompanyName = get_query_val('tblclients', 'companyname', array('id' => $params['userid']));
        if (!empty($clientCompanyName)) {
            $clientCompanyName = trim($clientCompanyName);
        }
    } elseif (isset($params['clientid']) && !empty($params['clientid'])) {
        // Query database for client company name using clientid
        $clientCompanyName = get_query_val('tblclients', 'companyname', array('id' => $params['clientid']));
        if (!empty($clientCompanyName)) {
            $clientCompanyName = trim($clientCompanyName);
        }
    }
    
    // Prepare customer data (use client company name from WHMCS profile)
    $customerData = array(
        'name' => $registrantContact['name'],
        'email' => $registrantContact['email'],
        'phone' => $registrantContact['phone'],
    );
    if (!empty($clientCompanyName)) {
        $customerData['company_name'] = $clientCompanyName;
    }
    
    // Prepare registrant_contact in API format (with postal_code instead of postcode)
    $registrantContactApi = array(
        'name' => $registrantContact['name'] ?? null,
        'email' => $registrantContact['email'] ?? null,
        'phone' => $registrantContact['phone'] ?? null,
        'organization' => $registrantContact['organization'] ?? null,
        'nid' => $registrantContact['nid'] ?? null,
        'address1' => $registrantContact['address1'] ?? null,
        'city' => $registrantContact['city'] ?? null,
        'state' => $registrantContact['state'] ?? null,
        'postal_code' => isset($registrantContact['postcode']) ? $registrantContact['postcode'] : null,
        'country' => $registrantContact['country'] ?? null,
    );
    
    // Remove null values to keep the payload clean
    $registrantContactApi = array_filter($registrantContactApi, function($value) {
        return $value !== null && $value !== '';
    });
    
    // Prepare registration data
    // Ensure regperiod is set, default to 1 year if not provided
    $regPeriod = isset($params['regperiod']) && !empty($params['regperiod']) ? intval($params['regperiod']) : 1;
    
    $registrationData = array(
        'domain' => $domain,
        'years' => $regPeriod,
        'period' => $regPeriod, // Keep for backward compatibility
        'nameservers' => $nameservers,
        'purpose' => isset($additionalFields['Purpose']) ? strtolower($additionalFields['Purpose']) : 
                     (isset($additionalFields['purpose']) ? strtolower($additionalFields['purpose']) : 'commercial'),
        'auto_renew' => false, // Always set to false
        'customer' => $customerData, // Use customer data with company_name from WHMCS profile
        'registrant_contact' => $registrantContactApi, // Explicit registrant contact field with NID and organization from additional fields, in API format
        'contacts' => array(
            'registrant' => $registrantContact, // Includes NID field and organization (keep original format for contacts)
            'admin' => $adminContact,
            'technical' => $technicalContact,
            'billing' => $billingContact,
        ),
    );
    
    // Add any additional TLD-specific fields
    if (!empty($additionalFields)) {
        $registrationData['additional_fields'] = $additionalFields;
    }
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/register',
        'POST',
        $registrationData
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    return array(
        'success' => true,
    );
}

/**
 * Transfer a domain
 */
function namelypartner_TransferDomain($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    // Helper function to clean phone number (remove dots)
    $cleanPhone = function($phone) {
        if (empty($phone)) {
            return '';
        }
        return str_replace('.', '', $phone);
    };
    
    $phone = !empty($params['phonenumberformatted']) ? $params['phonenumberformatted'] : $params['phonenumber'];
    $contactData = array(
        'name' => $params['firstname'] . ' ' . $params['lastname'],
        'email' => $params['email'],
        'phone' => $cleanPhone($phone),
        'organization' => $params['companyname'] ?? '',
    );
    
    $transferData = array(
        'domain' => $domain,
        'auth_code' => $params['eppcode'],
        'period' => $params['regperiod'],
        'auto_renew' => false, // Always set to false
        'customer' => $contactData,
    );
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/transfer',
        'POST',
        $transferData
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    return array(
        'success' => true,
    );
}

/**
 * Renew a domain
 */
function namelypartner_RenewDomain($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    $renewData = array(
        'domain' => $domain,
        'period' => $params['regperiod'],
    );
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/renew',
        'POST',
        $renewData
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    return array(
        'success' => true,
    );
}

/**
 * Get nameservers
 */
function namelypartner_GetNameservers($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    // Try /nameservers endpoint first
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/nameservers',
        'GET'
    );
    
    $nameservers = array();
    $nameserversFound = false;
    
    if ($result['success'] && isset($result['data'])) {
        $data = $result['data'];
        
        // Handle different response formats from /nameservers endpoint
        // Format 1: Direct array ["ns1.example.com", "ns2.example.com"]
        if (is_array($data) && isset($data[0]) && is_string($data[0])) {
            $nameservers = $data;
            $nameserversFound = true;
        }
        // Format 2: Nested {"nameservers": ["ns1.example.com", "ns2.example.com"]}
        elseif (isset($data['nameservers']) && is_array($data['nameservers'])) {
            $nameservers = $data['nameservers'];
            $nameserversFound = true;
        }
        // Format 3: primaryDns/secondaryDns/tertiaryDns format
        elseif (isset($data['primaryDns']) || isset($data['secondaryDns'])) {
            if (!empty($data['primaryDns'])) {
                $nameservers[] = $data['primaryDns'];
                $nameserversFound = true;
            }
            if (!empty($data['secondaryDns'])) {
                $nameservers[] = $data['secondaryDns'];
                $nameserversFound = true;
            }
            if (!empty($data['tertiaryDns'])) {
                $nameservers[] = $data['tertiaryDns'];
                $nameserversFound = true;
    }
        }
    }
    
    // Fallback to /info endpoint if /nameservers didn't return nameservers
    $infoResult = null;
    if (!$nameserversFound || empty($nameservers)) {
        $infoResult = namelypartner_ApiRequest(
            $params,
            '/partner-api/domains/' . $domain . '/info',
            'GET'
        );
        
        if ($infoResult['success'] && isset($infoResult['data'])) {
            $infoData = $infoResult['data'];
            
            // Extract from primaryDns, secondaryDns, tertiaryDns format
            if (!empty($infoData['primaryDns'])) {
                $nameservers[] = $infoData['primaryDns'];
                $nameserversFound = true;
            }
            if (!empty($infoData['secondaryDns'])) {
                $nameservers[] = $infoData['secondaryDns'];
                $nameserversFound = true;
            }
            if (!empty($infoData['tertiaryDns'])) {
                $nameservers[] = $infoData['tertiaryDns'];
                $nameserversFound = true;
            }
        }
    }
    
    // Format response for WHMCS
    $response = array();
    for ($i = 0; $i < count($nameservers) && $i < 5; $i++) {
        if (!empty($nameservers[$i])) {
            $response['ns' . ($i + 1)] = trim($nameservers[$i]);
    }
    }
    
    // If we have nameservers, return them
    if (!empty($response)) {
    return $response;
}

    // If no nameservers found but at least one API call succeeded, return empty response
    // WHMCS can handle empty nameserver arrays - domain might not have nameservers set yet
    if ($result['success'] || (isset($infoResult) && $infoResult['success'])) {
        // Return empty array - this is valid, domain might not have nameservers configured
        return array();
        }
    
    // Only return error if both API calls failed
    $errorMessage = 'Unable to retrieve nameservers';
    if (isset($result['error'])) {
        $errorMessage = $result['error'];
    }
    if (isset($infoResult) && !$infoResult['success'] && isset($infoResult['error'])) {
        $errorMessage = $infoResult['error'];
    }
    
        return array(
        'error' => $errorMessage,
    );
}

/**
 * Get DNS host records
 */
function namelypartner_GetDNS($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/dns',
        'GET'
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    // ApiRequest wraps the response in ['success' => true, 'data' => $apiResponse]
    // So $result['data'] contains the actual API response
    $apiResponse = $result['data'] ?? array();
    
    // Handle different response formats
    $records = array();
    // Format 1: API response has data key with array of records (your format)
    if (isset($apiResponse['data']) && is_array($apiResponse['data']) && !isset($apiResponse['data']['records'])) {
        $records = $apiResponse['data'];
    }
    // Format 2: API response.data.records format
    elseif (isset($apiResponse['data']['records']) && is_array($apiResponse['data']['records'])) {
        $records = $apiResponse['data']['records'];
    }
    // Format 3: API response.data is directly an array of records
    elseif (isset($apiResponse['data']) && is_array($apiResponse['data'])) {
        $records = $apiResponse['data'];
}
    // Format 4: API response has records at top level
    elseif (isset($apiResponse['records']) && is_array($apiResponse['records'])) {
        $records = $apiResponse['records'];
    }
    // Format 5: API response itself is an array of records
    elseif (is_array($apiResponse) && !isset($apiResponse['success']) && !isset($apiResponse['data'])) {
        $records = $apiResponse;
    }
    
    // Format records for WHMCS
    $hostRecords = array();
    foreach ($records as $record) {
        // Extract hostname from full name (e.g., "www.fwelcomes.com.bd" -> "www")
        $fullName = $record['name'] ?? '';
        $hostname = '';
        
        if (!empty($fullName)) {
            // Remove domain from name to get just the hostname
            $domainWithDot = '.' . $domain;
            if (strpos($fullName, $domainWithDot) !== false) {
                $hostname = str_replace($domainWithDot, '', $fullName);
            } elseif ($fullName === $domain) {
                // Root domain record
                $hostname = '@';
            } else {
                // If it doesn't match, use the full name as-is
                $hostname = $fullName;
            }
        }
        
        // Get address/value from API response
        $address = $record['value'] ?? $record['content'] ?? $record['address'] ?? '';
        
        // Get priority (for MX records)
        $priority = isset($record['priority']) && $record['priority'] !== null 
            ? (int)$record['priority'] 
            : (isset($record['mxpref']) ? (int)$record['mxpref'] : null);
        
        $hostRecords[] = array(
            'hostname' => $hostname,
            'type' => $record['type'] ?? '',
            'address' => $address,
            'priority' => $priority,
        );
    }
    
    return $hostRecords;
}

/**
 * Save DNS host records
 */
function namelypartner_SaveDNS($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    // Get DNS records from params
    // WHMCS may pass records in different formats:
    // 1. dnsrecords array (most common)
    // 2. dnsrecord array (singular)
    // 3. Individual record parameters
    $dnsRecords = array();
    
    if (isset($params['dnsrecords']) && is_array($params['dnsrecords'])) {
        $dnsRecords = $params['dnsrecords'];
    } elseif (isset($params['dnsrecord']) && is_array($params['dnsrecord'])) {
        $dnsRecords = $params['dnsrecord'];
    } else {
        // Try to collect individual record parameters
        // WHMCS might pass records as dnsrecord[0][hostname], dnsrecord[0][type], etc.
        $i = 0;
        while (isset($params["dnsrecord{$i}"]) || isset($params["dnsrecord[{$i}]"])) {
            $recordKey = isset($params["dnsrecord{$i}"]) ? "dnsrecord{$i}" : "dnsrecord[{$i}]";
            if (is_array($params[$recordKey])) {
                $dnsRecords[] = $params[$recordKey];
            }
            $i++;
        }
    }
    
    // Format records for API
    // Note: Empty array is valid - it means delete all records when replace_all is true
    $records = array();
    
    // Process each record
    foreach ($dnsRecords as $record) {
        // Skip empty or invalid records
        if (empty($record) || !is_array($record)) {
            continue;
        }
        
        // Skip records that are marked for deletion (if WHMCS sends such markers)
        if (isset($record['deleted']) && $record['deleted']) {
            continue;
        }
        $hostname = $record['hostname'] ?? '';
        $type = strtoupper(trim($record['type'] ?? ''));
        $address = trim($record['address'] ?? '');
        
        // Validate required fields
        if (empty($type) || empty($address)) {
            // Skip invalid records but log them
            continue;
        }
        
        $ttl = isset($record['ttl']) && $record['ttl'] !== null 
            ? (int)$record['ttl'] 
            : 3600; // Default TTL
        $priority = isset($record['priority']) && $record['priority'] !== null 
            ? (int)$record['priority'] 
            : null;
        
        // Normalize hostname: "@" or empty string for root domain
        if ($hostname === '@') {
            $hostname = '';
        }
        
        // Format record for API
        $apiRecord = array(
            'hostname' => $hostname, // Empty string or "@" for root domain
            'type' => $type,
            'address' => $address,
            'ttl' => $ttl,
        );
        
        // Add priority for MX and SRV records
        if ($priority !== null) {
            $apiRecord['priority'] = $priority;
        }
        
        // Add SRV-specific fields
        if (strtoupper($type) === 'SRV') {
            if (isset($record['weight']) && $record['weight'] !== null) {
                $apiRecord['weight'] = (int)$record['weight'];
            }
            if (isset($record['port']) && $record['port'] !== null) {
                $apiRecord['port'] = (int)$record['port'];
            }
        }
        
        $records[] = $apiRecord;
    }
    
    // Prepare request data
    // Note: If $records is empty and replace_all is true, all existing records will be deleted
    $requestData = array(
        'records' => $records,
        'replace_all' => true, // Replace all existing records (deletes records not in the array)
    );
    
    // Send records to API
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/dns/update',
        'POST',
        $requestData
    );
    
    if (!$result['success']) {
        $errorMessage = isset($result['error']) ? $result['error'] : 'Unknown error occurred';
        return array(
            'error' => $errorMessage,
        );
    }
    
    return array(
        'success' => true,
    );
}

/**
 * Save nameservers
 */
function namelypartner_SaveNameservers($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    // Collect nameservers from params
    $nameservers = array();
    for ($i = 1; $i <= 5; $i++) {
        if (!empty($params["ns{$i}"])) {
            $nameservers[] = trim($params["ns{$i}"]);
        }
    }
    
    // Validate at least one nameserver is provided
    if (empty($nameservers)) {
        return array(
            'error' => 'At least one nameserver is required.',
        );
    }
    
    // Validate nameserver format (basic validation)
    foreach ($nameservers as $ns) {
        if (strlen($ns) < 3 || strlen($ns) > 253) {
    return array(
                'error' => 'Invalid nameserver format: ' . $ns,
    );
        }
}

    // Prepare request data
    // API expects nameservers as an array
    $requestData = array(
        'nameservers' => $nameservers
    );
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/nameservers',
        'POST',
        $requestData
    );
    
    if (!$result['success']) {
        // Provide more detailed error message
        $errorMsg = isset($result['error']) ? $result['error'] : 'Failed to update nameservers';
        
        return array(
            'error' => $errorMsg,
        );
    }
    
    return array(
        'success' => true,
    );
}



/**
 * Unsuspend domain
 */
function namelypartner_UnsuspendDomain($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    // Make API call to unsuspend domain
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/unsuspend',
        'POST',
        array()
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    return array(
        'success' => true,
    );
}

/**
 * Request domain deletion
 */


/**
 * Helper function to parse domain info API response
 * Standardizes the response format from /info endpoint
 * 
 * @param array $data Raw API response data
 * @return array Formatted data for WHMCS
 */
function namelypartner_ParseDomainInfo($data)
{
    $formatted = array();
    
    // Parse expiry date - handle multiple formats
    $expiryDate = null;
    if (isset($data['expiryDate'])) {
        // API returns format: "22/11/2026" (DD/MM/YYYY)
        $expiryDate = DateTime::createFromFormat('d/m/Y', $data['expiryDate']);
    } elseif (isset($data['expires_at'])) {
        $expiryDate = new DateTime($data['expires_at']);
    } elseif (isset($data['expiry_date'])) {
        $expiryDate = new DateTime($data['expiry_date']);
    }
    
    if ($expiryDate) {
        $formatted['expirydate'] = $expiryDate->format('Y-m-d');
    }
    
    // Parse activation date
    $activationDate = null;
    if (isset($data['activationDate'])) {
        // API returns format: "22/11/2025" (DD/MM/YYYY)
        $activationDate = DateTime::createFromFormat('d/m/Y', $data['activationDate']);
    } elseif (isset($data['activation_date'])) {
        $activationDate = new DateTime($data['activation_date']);
    } elseif (isset($data['registered_at'])) {
        $activationDate = new DateTime($data['registered_at']);
    }
    
    if ($activationDate) {
        $formatted['registrationdate'] = $activationDate->format('Y-m-d');
    }
    
    // Extract nameservers
    $nameservers = array();
    if (!empty($data['primaryDns'])) {
        $nameservers[] = $data['primaryDns'];
    }
    if (!empty($data['secondaryDns'])) {
        $nameservers[] = $data['secondaryDns'];
    }
    if (!empty($data['tertiaryDns'])) {
        $nameservers[] = $data['tertiaryDns'];
        }
    if (!empty($nameservers)) {
        $formatted['nameservers'] = $nameservers;
        // Format for WHMCS ns1, ns2, etc.
        for ($i = 0; $i < count($nameservers) && $i < 5; $i++) {
            $formatted['ns' . ($i + 1)] = $nameservers[$i];
        }
    }
    
    // Parse status
    if (isset($data['status'])) {
        $status = strtolower($data['status']);
        
        if ($status == 'active' || $status == 'success') {
            $formatted['active'] = true;
        } elseif ($status == 'expired') {
            $formatted['expired'] = true;
        } elseif ($status == 'cancelled' || $status == 'deleted') {
            $formatted['cancelled'] = true;
        } elseif ($status == 'transferred') {
            $formatted['transferredaway'] = true;
        } elseif ($status == 'pending' || $status == 'pendingtransfer') {
            $formatted['pending'] = true;
        }
        
        $formatted['status'] = $data['status'];
    }
    
    // Client/Registrant information
    if (isset($data['clientFullName'])) {
        $formatted['registrant_name'] = $data['clientFullName'];
    }
    if (isset($data['clientNid'])) {
        $formatted['registrant_nid'] = $data['clientNid'];
    }
    if (isset($data['clientEmail'])) {
        $formatted['registrant_email'] = $data['clientEmail'];
    }
    if (isset($data['clientContactAddress'])) {
        $formatted['registrant_address'] = $data['clientContactAddress'];
    }
    if (isset($data['clientContactNumber'])) {
        $formatted['registrant_phone'] = $data['clientContactNumber'];
        }
    
    // Domain name
    if (isset($data['domain'])) {
        $formatted['domain'] = $data['domain'];
    }
    
    // Response code
    if (isset($data['responseCode'])) {
        $formatted['responseCode'] = $data['responseCode'];
    }
    
    return $formatted;
}

/**
 * Sync domain status and expiry date
 */
function namelypartner_Sync($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/info',
        'GET'
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    // Use helper function to parse domain info response
    $data = $result['data'];
    $response = namelypartner_ParseDomainInfo($data);
    
    return $response;
}

/**
 * Check transfer status
 */
function namelypartner_TransferSync($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/transfer-status',
        'GET'
    );
    
    if (!$result['success']) {
        return array(
            'error' => $result['error'],
        );
    }
    
    $data = $result['data'];
    $status = strtolower($data['status']);
    
    $response = array();
    
    if ($status == 'completed' || $status == 'complete') {
        $response['completed'] = true;
        
        // Handle expiry date in different formats
        $expiryDate = null;
        if (isset($data['expiryDate'])) {
            $expiryDate = DateTime::createFromFormat('d/m/Y', $data['expiryDate']);
        } elseif (isset($data['expires_at'])) {
            $expiryDate = new DateTime($data['expires_at']);
        } elseif (isset($data['expiry_date'])) {
            $expiryDate = new DateTime($data['expiry_date']);
        }
        
        if ($expiryDate) {
            $response['expirydate'] = $expiryDate->format('Y-m-d');
        }
    } elseif ($status == 'failed' || $status == 'rejected') {
        $response['failed'] = true;
        $response['reason'] = isset($data['message']) ? $data['message'] : 'Transfer failed';
    }
    
    return $response;
}

/**
 * Get domain information (WHMCS 7.6+)
 * 
 * This function returns a Domain object with all domain information including
 * nameservers, expiry date, and more.
 * 
 * @param array $params Module parameters
 * @return Domain WHMCS Domain object
 * @throws Exception If API call fails
 */
function namelypartner_GetDomainInformation($params)
{
    $domain = $params['sld'] . '.' . $params['tld'];
    
    $result = namelypartner_ApiRequest(
        $params,
        '/partner-api/domains/' . $domain . '/info',
        'GET'
    );
    
    if (!$result['success']) {
        throw new Exception($result['error']);
    }
    
    // Parse domain info response
    // API response structure: {success: true, data: {...}, contacts: {...}}
    $data = $result['data'];
    $formatted = namelypartner_ParseDomainInfo($data);
    
    // Get contacts from top-level response (not in data)
    $contacts = isset($result['contacts']) ? $result['contacts'] : null;
    
    // Build Domain object
    $domainObj = new Domain();
    
    // Set domain name
    if (isset($formatted['domain'])) {
        $domainObj->setDomain($formatted['domain']);
    } else {
        $domainObj->setDomain($domain);
    }
    
    // Set nameservers
    if (isset($formatted['nameservers']) && is_array($formatted['nameservers'])) {
        $domainObj->setNameservers($formatted['nameservers']);
    } elseif (isset($formatted['ns1'])) {
        // Fallback to ns1, ns2 format
        $nameservers = array();
        for ($i = 1; $i <= 5; $i++) {
            if (isset($formatted['ns' . $i]) && !empty($formatted['ns' . $i])) {
                $nameservers[] = $formatted['ns' . $i];
            }
        }
        if (!empty($nameservers)) {
            $domainObj->setNameservers($nameservers);
        }
    }
    
    // Set expiry date
    if (isset($formatted['expirydate'])) {
        try {
            $expiryDate = Carbon::createFromFormat('Y-m-d', $formatted['expirydate']);
            $domainObj->setExpiryDate($expiryDate);
        } catch (Exception $e) {
            // If date parsing fails, try alternative formats
            if (isset($data['expiryDate'])) {
                $expiryDate = Carbon::createFromFormat('d/m/Y', $data['expiryDate']);
                $domainObj->setExpiryDate($expiryDate);
            }
        }
    }
    
    // Set registration status
    if (isset($formatted['status'])) {
        $status = strtolower($formatted['status']);
        if ($status == 'active' || $status == 'success') {
            $domainObj->setRegistrationStatus('Active');
        } elseif ($status == 'expired') {
            $domainObj->setRegistrationStatus('Expired');
        } elseif ($status == 'cancelled' || $status == 'deleted') {
            $domainObj->setRegistrationStatus('Cancelled');
        } elseif ($status == 'pending') {
            $domainObj->setRegistrationStatus('Pending');
        }
    } elseif (isset($formatted['active']) && $formatted['active']) {
        $domainObj->setRegistrationStatus('Active');
    }
    
    // Set registrant email from contacts in /info response
    if ($contacts && isset($contacts['registrant']['email'])) {
        $domainObj->setRegistrantEmailAddress($contacts['registrant']['email']);
    } elseif (isset($formatted['registrant_email'])) {
        $domainObj->setRegistrantEmailAddress($formatted['registrant_email']);
    } elseif (isset($data['clientEmail'])) {
        $domainObj->setRegistrantEmailAddress($data['clientEmail']);
    }
    
    // Set registration date if available
    if (isset($formatted['registrationdate'])) {
        try {
            $regDate = Carbon::createFromFormat('Y-m-d', $formatted['registrationdate']);
            // Note: Domain object doesn't have setRegistrationDate, but we can track it
        } catch (Exception $e) {
            // Ignore date parsing errors for registration date
        }
    }
    
    return $domainObj;
}

/**
 * Client area custom button array
 */
function namelypartner_ClientAreaCustomButtonArray()
{
    return array();
}

/**
 * Client area allowed functions
 */
function namelypartner_ClientAreaAllowedFunctions()
{
    return array();
}


/**
 * Sync domain function for admin button
 */
function namelypartner_syncDomain($params)
{
    $result = namelypartner_Sync($params);
    
    if (isset($result['error'])) {
        return array(
            'error' => $result['error'],
        );
    }
    
    return array(
        'success' => 'Domain synchronized successfully',
    );
}



